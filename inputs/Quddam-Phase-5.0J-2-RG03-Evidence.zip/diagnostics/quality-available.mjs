/** Available quality checks only. Native/browser gate is separately blocked at environment preflight. */
import {spawn} from 'node:child_process';
import {readFileSync,writeFileSync,mkdirSync,appendFileSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {createHash,randomBytes} from 'node:crypto';
const root=resolve(import.meta.dirname,'..'),app=join(root,'qalba-platform'),out=join(root,'verification/rg03-available-quality');
mkdirSync(out,{recursive:true});
const source=JSON.parse(readFileSync(join(root,'Source-Manifest.json'))),originalNextEnv=readFileSync(join(app,'next-env.d.ts'));
const env={...process.env,DATABASE_URL:'postgresql://postgres@127.0.0.1:55453/rg03_quality',DATABASE_POOL_MAX:'8',NEXT_TELEMETRY_DISABLED:'1',DISABLE_PRISMA_TELEMETRY:'true',NODE_OPTIONS:'--max-old-space-size=3072',AUTH_RATE_LIMIT_SECRET:randomBytes(32).toString('hex'),AUTH_TRUST_PROXY:'true',AUTH_CLIENT_IP_HEADER:'x-quddam-client-ip',PUBLIC_WELCOME_CREDITS_ENABLED:'false',SMTP_HOST:'127.0.0.1',SMTP_PORT:'2525',SMTP_FROM:'synthetic@example.test'};
delete env.APP_URL; delete env.LD_PRELOAD; delete env.LD_LIBRARY_PATH; delete env.E2E_DATABASE_URL;
const receipt={phase:'5.0J-2-RG03',sourceFingerprint:source.sourceFingerprint,previousPassClaimsInherited:false,canonicalOrNativePassesClaimed:0,steps:[],passed:false};
function save(){writeFileSync(join(root,'RG03-Available-Quality-Gates.json'),JSON.stringify(receipt,null,2));}
function guard(){for(const[n,h]of Object.entries(source.files))if(createHash('sha256').update(readFileSync(join(app,n))).digest('hex')!==h)throw Error('Authored source mismatch '+n);}
async function run(label,args,extra={}){
 const row={label,command:['npm',...args],startedAt:new Date().toISOString(),status:'RUNNING'};receipt.steps.push(row);save();
 writeFileSync(join(out,label+'.log'),'');console.log('RUN '+label);
 const code=await new Promise((ok,bad)=>{const p=spawn('npm',args,{cwd:app,env:{...env,...extra},stdio:['ignore','pipe','pipe']});
  for(const s of[p.stdout,p.stderr])s.on('data',b=>appendFileSync(join(out,label+'.log'),b));p.on('error',bad);p.on('exit',ok);});
 row.exitCode=code;row.status=code===0?'PASSED':'FAILED';row.finishedAt=new Date().toISOString();save();
 if(code!==0)throw Error('STOP first new failing available quality check: '+label);
 if(label.endsWith('auth-tests')||label==='test'){
  const native=JSON.parse(readFileSync(join(out,label+'.json')));
  row.passed=native.numPassedTests;row.failed=native.numFailedTests;row.skipped=native.numPendingTests;save();
  if(!native.success||native.numFailedTests||native.numPendingTests)throw Error('Unclean unit test result: '+label);
 }
 console.log('PASS '+label);
}
try{
 guard();
 await run('prisma-generate',['run','db:generate']);guard();
 await run('lint',['run','lint']);guard();
 await run('typecheck',['run','typecheck']);guard();
 await run('test',['run','test','--','--reporter=default','--reporter=json','--outputFile='+join(out,'test.json')]);guard();
 await run('build',['run','build'],{NODE_ENV:'production',APP_URL:'https://quddam.synthetic.test'});
 writeFileSync(join(app,'next-env.d.ts'),originalNextEnv);guard();
 await run('typecheck-restored-baseline',['run','typecheck']);guard();
 receipt.passed=true;receipt.completedAt=new Date().toISOString();save();console.log('AVAILABLE QUALITY COMPLETE; final gate remains blocked pending runtime restoration');
}catch(e){receipt.error=String(e);receipt.stoppedAt=receipt.steps.at(-1)?.label;receipt.finishedAt=new Date().toISOString();save();throw e;}
finally{writeFileSync(join(app,'next-env.d.ts'),originalNextEnv);}

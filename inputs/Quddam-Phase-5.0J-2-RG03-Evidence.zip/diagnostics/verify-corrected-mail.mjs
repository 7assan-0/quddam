import nodeNet from 'node:net';
import {spawnSync} from 'node:child_process';
import http from 'node:http';
import {mkdirSync,writeFileSync,readFileSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {createHash} from 'node:crypto';
const root=resolve(import.meta.dirname,'..'), privateDir=join(root,'private-corrected-diagnostic-mail');
mkdirSync(privateDir,{recursive:true,mode:0o700});
let smtp,mailWeb,received=0;
const net={createServer(listener){return nodeNet.createServer(socket=>{
 let pending='',body=false,message='';
 socket.on('data',bytes=>{pending+=bytes.toString();while(pending.includes('\r\n')){
  const n=pending.indexOf('\r\n'),line=pending.slice(0,n);pending=pending.slice(n+2);
  if(body){if(line!=='.'){message+=line+'\r\n';continue;}
   writeFileSync(join(privateDir,String(++received).padStart(3,'0')+'.eml'),message,{mode:0o600});body=false;message='';
  }else if(/^DATA$/i.test(line))body=true;
 }});
 listener(socket);
});}};
function mailHarness(){const mailbox=new Map();smtp=net.createServer(socket=>{socket.write('220 synthetic SMTP\r\n');let pending='',body=false,message='',to='';socket.on('data',bytes=>{pending+=bytes.toString();while(pending.includes('\r\n')){const n=pending.indexOf('\r\n'),line=pending.slice(0,n);pending=pending.slice(n+2);if(body){if(line!=='.'){message+=(line.startsWith('..')?line.slice(1):line)+'\r\n';continue;}const parsed=spawnSync(process.env.PYTHON??'python3',[join(root,'verification-tools/mail-mime.py')],{input:message,encoding:'utf8'});if(parsed.error||parsed.status!==0)throw Error('Synthetic MIME parsing failed');const record=JSON.parse(parsed.stdout);if(record.url)mailbox.set(to,record);message='';body=false;socket.write('250 accepted\r\n');continue;}if(/^EHLO|^HELO/i.test(line))socket.write('250-synthetic\r\n250 8BITMIME\r\n');else if(/^RCPT TO:/i.test(line)){to=line.match(/<([^>]+)>/)?.[1]??'';socket.write('250 OK\r\n');}else if(/^DATA$/i.test(line)){body=true;socket.write('354 send data\r\n');}else if(/^QUIT$/i.test(line)){socket.end('221 Bye\r\n');}else socket.write('250 OK\r\n');}});});mailWeb=http.createServer((req,res)=>{const to=new URL(req.url,'http://localhost').searchParams.get('to');res.setHeader('Content-Type','application/json');res.end(JSON.stringify(mailbox.get(to)??{}));});return Promise.all([new Promise(r=>smtp.listen(2525,'127.0.0.1',r)),new Promise(r=>mailWeb.listen(2528,'127.0.0.1',r))]);}

const mailPath=join(root,'qalba-platform/src/lib/auth/mail.ts');
process.env.SMTP_HOST='127.0.0.1';process.env.SMTP_PORT='2525';process.env.SMTP_FROM='synthetic@example.test';process.env.APP_URL='http://127.0.0.1:3000';
delete process.env.SMTP_USER;delete process.env.SMTP_PASSWORD;
const {sendResetMail}=await import(mailPath);
let mailbox,urlError;
try{
 await mailHarness();
 for(let i=0;i<3;i++)await sendResetMail('rg03-synthetic@example.test',String(i+1).repeat(64));
 mailbox=await(await fetch('http://127.0.0.1:2528/latest?to=rg03-synthetic%40example.test')).json();
 try{new URL(mailbox.url);}catch(e){urlError={name:e.name,message:e.message};}
 const receipt={actualProductMailer:true,productMailerSha256:createHash('sha256').update(readFileSync(mailPath)).digest('hex'),syntheticOnly:true,emailsSent:3,mailboxKeys:Object.keys(mailbox),correctedUrlValid:new URL(mailbox.url).pathname==='/reset-password',tokensRedacted:true,canonicalScenarioExecuted:false,dependencyOrProductChanges:0};
 writeFileSync(join(root,'RG03-Corrected-Mail-Component-Verification.json'),JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt));
}finally{for(const s of [smtp,mailWeb])if(s)await new Promise(r=>s.close(r));}

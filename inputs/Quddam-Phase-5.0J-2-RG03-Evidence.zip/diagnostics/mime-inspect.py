#!/usr/bin/env python3
"""Independent standard-library MIME diagnosis; only redacted metadata is emitted."""
import hashlib
import json
import re
import sys
from email import policy
from email.parser import BytesParser
from pathlib import Path
from urllib.parse import urlsplit, parse_qs

rows = []
for source in sorted(Path(sys.argv[1]).glob('*.eml')):
    raw = source.read_bytes()
    message = BytesParser(policy=policy.default).parsebytes(raw)
    parts = []
    for part in message.walk():
        if part.is_multipart():
            parts.append({'contentType': part.get_content_type(), 'multipart': True,
                          'childParts': len(part.get_payload()), 'defects': [type(d).__name__ for d in part.defects]})
            continue
        text = part.get_content() if part.get_content_maintype() == 'text' else ''
        links = re.findall(r'https?://[^\s<>\"\']+', text)
        inspected = []
        for link in links:
            parsed = urlsplit(link)
            token = parse_qs(parsed.query).get('token', [])
            inspected.append({'redactedUrl': f'{parsed.scheme}://{parsed.netloc}{parsed.path}?token=[REDACTED]',
                              'complete': bool(parsed.scheme and parsed.netloc and parsed.path),
                              'syntacticallyValid': parsed.scheme in ('http', 'https') and bool(parsed.hostname) and bool(token and token[0]),
                              'resetPathCorrect': parsed.path == '/reset-password',
                              'tokenPresent': bool(token and token[0]), 'tokenCharacters': len(token[0]) if token else 0})
        parts.append({'contentType': part.get_content_type(), 'charset': part.get_content_charset(),
                      'contentTransferEncoding': part.get('Content-Transfer-Encoding', '7bit'),
                      'multipart': False, 'decodedBytes': len(part.get_payload(decode=True) or b''),
                      'decodedResetUrls': inspected, 'defects': [type(d).__name__ for d in part.defects]})
    legacy = re.sub(r'=([\da-f]{2})', lambda m: chr(int(m[1], 16)), re.sub(r'=\r?\n', '', raw.decode()), flags=re.I)
    rows.append({'mailOrdinal': len(rows)+1, 'rawSha256': hashlib.sha256(raw).hexdigest(), 'rawBytes': len(raw),
                 'contentTypeHeader': message.get('Content-Type'),
                 'contentTransferEncodingHeader': message.get('Content-Transfer-Encoding'),
                 'multipart': message.is_multipart(),
                 'textPlainExists': any(p.get_content_type() == 'text/plain' for p in message.walk()),
                 'textHtmlExists': any(p.get_content_type() == 'text/html' for p in message.walk()),
                 'legacyExtractorFindsUrl': bool(re.search(r'https?://[^\s<>]+', legacy)), 'parts': parts})
result = {'diagnosis': 'A' if rows and all(r['contentTransferEncodingHeader'] == 'base64' and not r['legacyExtractorFindsUrl'] and any(p.get('decodedResetUrls') for p in r['parts']) for r in rows) else 'UNRESOLVED',
          'syntheticOnly': True, 'tokensRedacted': True, 'parser': 'Python email.parser.BytesParser(policy=default)',
          'canonicalScenarioExecuted': False, 'scope': 'Actual frozen product sendResetMail and original SMTP harness component reproduction', 'messages': rows}
Path(sys.argv[2]).write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))

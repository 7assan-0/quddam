/** Rebuild after preserving the restored-cache internal Turbopack failure; no authored edits. */
import {spawn} from 'node:child_process';
import {readFileSync,writeFileSync,mkdirSync,appendFileSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {createHash,randomBytes} from 'node:crypto';
const root=resolve(import.meta.dirname,'..'),app=join(root,'qalba-platform'),out=join(root,'verification/rg03-fresh-build');mkdirSync(out,{recursive:true});
const source=JSON.parse(readFileSync(join(root,'Source-Manifest.json'))),originalNextEnv=readFileSync(join(app,'next-env.d.ts'));
const env={...process.env,DATABASE_URL:'postgresql://postgres@127.0.0.1:55453/rg03_quality',DATABASE_POOL_MAX:'8',APP_URL:'https://quddam.synthetic.test',AUTH_RATE_LIMIT_SECRET:randomBytes(32).toString('hex'),AUTH_TRUST_PROXY:'true',AUTH_CLIENT_IP_HEADER:'x-quddam-client-ip',PUBLIC_WELCOME_CREDITS_ENABLED:'false',SMTP_HOST:'127.0.0.1',SMTP_PORT:'2525',SMTP_FROM:'synthetic@example.test',NEXT_TELEMETRY_DISABLED:'1',DISABLE_PRISMA_TELEMETRY:'true',NODE_OPTIONS:'--max-old-space-size=3072'};
delete env.LD_PRELOAD;delete env.LD_LIBRARY_PATH;
const receipt={phase:'5.0J-2-RG03',sourceFingerprint:source.sourceFingerprint,authoredChanges:0,restoredCacheQuarantined:true,steps:[],passed:false};
function save(){writeFileSync(join(root,'RG03-Fresh-Build.json'),JSON.stringify(receipt,null,2));}
function guard(){for(const[n,h]of Object.entries(source.files))if(createHash('sha256').update(readFileSync(join(app,n))).digest('hex')!==h)throw Error('Authored source mismatch '+n);}
async function run(label,args,extra){
 const row={label,command:['npm',...args],startedAt:new Date().toISOString(),status:'RUNNING'};receipt.steps.push(row);save();writeFileSync(join(out,label+'.log'),'');console.log('RUN '+label);
 const code=await new Promise((ok,bad)=>{const p=spawn('npm',args,{cwd:app,env:{...env,...extra},stdio:['ignore','pipe','pipe']});for(const s of[p.stdout,p.stderr])s.on('data',b=>appendFileSync(join(out,label+'.log'),b));p.on('error',bad);p.on('exit',ok);});
 row.exitCode=code;row.status=code===0?'PASSED':'FAILED';row.finishedAt=new Date().toISOString();save();if(code!==0)throw Error('STOP fresh build failure: '+label);console.log('PASS '+label);
}
try{guard();await run('build',['run','build'],{NODE_ENV:'production'});writeFileSync(join(app,'next-env.d.ts'),originalNextEnv);guard();await run('typecheck-restored-baseline',['run','typecheck'],{});guard();receipt.passed=true;receipt.completedAt=new Date().toISOString();save();}
catch(e){receipt.error=String(e);receipt.finishedAt=new Date().toISOString();save();throw e;}
finally{writeFileSync(join(app,'next-env.d.ts'),originalNextEnv);}

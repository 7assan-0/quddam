#!/usr/bin/env python3
"""Independent MIME fixtures; never count these as canonical release identities."""
import importlib.util
import json
from email import policy
from email.message import EmailMessage
from pathlib import Path

root = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location('mail_mime', root / 'verification-tools/mail-mime.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
url = 'http://127.0.0.1:3000/reset-password?token=synthetic-only&check=1'
rows = []


def check(name, raw, expected=url):
    record = module.mailbox_record(raw)
    assert record == ({'url': expected} if expected else {}), name
    rows.append({'name': name, 'passed': True})


for index, raw in enumerate(sorted((root / 'private-diagnostic-mail').glob('*.eml')), start=1):
    check(f'actual-product-base64-message-{index}', raw.read_bytes(),
          f'http://127.0.0.1:3000/reset-password?token={str(index)*64}')
for cte in ('base64', 'quoted-printable', '8bit', '7bit'):
    message = EmailMessage(policy=policy.SMTP)
    body = f'استعادة قدّام {url}' if cte != '7bit' else f'Reset {url}'
    message.set_content(body, cte=cte)
    check(f'single-text-plain-{cte}', message.as_bytes())
message = EmailMessage(policy=policy.SMTP)
message.set_content(f'استعادة قدّام {url}', cte='quoted-printable')
assert b'=\r\n' in message.as_bytes()
check('quoted-printable-soft-wrap', message.as_bytes())
message = EmailMessage(policy=policy.SMTP)
message.set_content(f'استعادة قدّام {url}', cte='base64')
message.add_alternative(f'<a href="{url.replace("&", "&amp;")}">استعادة</a>', subtype='html', cte='quoted-printable')
check('multipart-alternative-base64-plain-qp-html', message.as_bytes())
message = EmailMessage(policy=policy.SMTP)
message.set_content(f'<a href="{url.replace("&", "&amp;")}">استعادة</a>', subtype='html', cte='base64')
check('html-only-base64-entities', message.as_bytes())
message = EmailMessage(policy=policy.SMTP)
message.set_content('No reset URL here', cte='quoted-printable')
message.add_attachment(url.encode(), maintype='text', subtype='plain', filename='unrelated.txt')
check('attachment-url-is-not-message-body', message.as_bytes(), None)
message = EmailMessage(policy=policy.SMTP)
message.set_content('No reset URL here', cte='base64')
check('missing-reset-link-remains-missing', message.as_bytes(), None)
report = {'scope': 'test MIME harness verification only', 'passed': len(rows), 'failed': 0, 'skipped': 0,
          'retries': 0, 'syntheticOnly': True, 'tokensRedacted': True, 'canonicalM05PassClaimed': False, 'cases': rows}
(root / 'RG03-MIME-Harness-Verification.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))

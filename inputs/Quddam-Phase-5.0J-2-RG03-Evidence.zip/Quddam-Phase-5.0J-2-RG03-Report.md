# Quddam Phase 5.0J-2-RG03 — M05 diagnosis and verification report

**Verdict: BLOCKED. No Release Candidate.** A controlled reproduction using the frozen product mailer proves hypothesis A at the mail-component boundary: Nodemailer emits a valid base64 MIME body, while the original external test harness only decodes quoted-printable and therefore supplies no URL. The harness-only correction passes component checks. The unchanged canonical M05 scenario and complete final release gate remain **NOT EXECUTED** because the native PostgreSQL and Chromium executables used by the frozen verification tools are unavailable in this execution environment.

No product defect is established. This is an incomplete release verification, not a release approval.

## Baseline and scope

Only `Quddam-Phase-5.0J-2-RG02-frozen-checkpoint.zip` supplied the baseline source and verification tools. It was retrieved anew and verified before diagnosis.

| Item | SHA256 |
| --- | --- |
| Frozen RG02 archive | `55f544c7b8a3b2276adeaab00f7f64d79f8aec34ca29be68287542778333af34` |
| Authored application source, all 670 files | `bbb44ee4250b85a9baeba7d441676d2fdfe10e38b32e8d55ee301d4598db72df` |
| Unchanged canonical `public-ingress.spec.ts` | `09e1921b6f4e3d38ef43618a7ac474b617c9727ee485e1db44a297ac77568300` |
| Corrected verification harness set | `47704bed3bc1d25e1ce50f14d2a5b1eaad74c67d0598119d8d9ad73009a7ff52` |
| Application plus verification-harness files, 692 files | `9d64d4c08e8df1af80eff4bb4eb5feed3a7946eeb20e025de9be8e93c068f510` |
| `package-lock.json` | `c3fcb1733f2281008ef45ace458ce5659de2a51c5aa9350688a01b212aa5602c` |
| Prisma schema | `908f851226554d0a451ebd3bbca9e9d3a185643bd91d97cce5c9ceda64e4a23c` |

The authored application fingerprint stays unchanged because the correction is confined to external test tools. The separate harness and combined fingerprints distinguish the corrected verification source. All 25 migration files, including the lock file, match RG02; their individual fingerprints appear in `RG03-Schema-Dependency-Migration-Integrity.json`.

RG02 remains closed. Its Bluff correction was retained byte-for-byte and was not revisited. No application, assertion, timeout, recovery budget, token lifetime, session policy, gameplay, billing, SSE, CSP, branding, dependency, schema or migration change was made. There was no deployment, production operation, commit or push.

## Diagnosis and its limits

The original RG02 observation was `TypeError: Invalid URL` at `new URL(mailbox.url)` after the recovery-response and PasswordReset row-count assertions passed. RG02 did not retain the original SMTP payload. Those historical assertions are not counted as new RG03 executions.

Before patching, `diagnostics/reproduce-original-mail.mjs` invoked the actual frozen `src/lib/auth/mail.ts::sendResetMail` three times with synthetic addresses and synthetic, non-persisted tokens. A passive SMTP observer captured the messages while the original `mailHarness()` function ran unchanged. The mailbox response had no keys, and `new URL(mailbox.url)` produced the same `TypeError: Invalid URL`.

An independent Python `email.parser.BytesParser(policy=default)` inspection then produced the following result for every captured message:

| Property | Observation |
| --- | --- |
| Content-Type | `text/plain; charset="utf-8"` |
| Content-Transfer-Encoding | `base64` |
| Multipart | No; one text body |
| `text/plain` present | Yes |
| `text/html` present | No |
| MIME parser defects | None |
| Reset URL after MIME decoding | Present, complete and syntactically valid |
| Decoded URL | `http://127.0.0.1:3000/reset-password?token=[REDACTED]` |
| Original quoted-printable-only extractor | No URL found |

**Hypothesis A is proven for this controlled, actual-product-mail reproduction.** B is not needed to explain the reproduced failure. C is not supported: the captured product messages contain valid reset content. This component execution did not create PasswordReset rows or exercise browser/session behavior, so it cannot replace the canonical M05 diagnostic or verification run.

The evidence contains redacted MIME captures, MIME metadata, capture hashes, reproduction code and safe receipts. No real user mail, credentials, cookies or live tokens are included. The synthetic tokens are redacted from shared captures.

## Exact authorized correction

`Authorized-RG03-Mail-Harness-Patch.diff` contains the complete correction:

1. `verification-tools/consolidated-runner.mjs::mailHarness()` invokes the installed Python MIME parser instead of applying quoted-printable substitution to the entire raw message. It preserves the mailbox JSON contract and removes SMTP transport dot-stuffing before parsing.
2. New `verification-tools/mail-mime.py` uses the existing Python standard-library MIME parser to decode text bodies, respecting per-part transfer encoding and charset. It supports base64, quoted-printable, multipart plain/HTML alternatives and HTML link entities, and excludes attachment URLs. Missing reset content still returns an empty mailbox record; the canonical test remains responsible for validating the URL.

No suitable installed JavaScript mail parser was present. Python's installed MIME parser supplies standards-aware parsing without adding a dependency. The relevant MIME specifications are [RFC 2045](https://www.rfc-editor.org/rfc/rfc2045) and [RFC 2046](https://www.rfc-editor.org/rfc/rfc2046).

All 670 authored application files and all canonical M05 assertions are byte-identical to RG02.

## Current verification results

| Check | Current RG03 result |
| --- | --- |
| Original actual-mail component reproduction | Reproduced empty mailbox and `Invalid URL` |
| Corrected actual-mail SMTP/mailbox component | PASS; valid decoded reset URL |
| MIME harness fixtures | 12 PASS; 0 failed; 0 skipped; 0 retries |
| Related auth/reset unit checks | 57 PASS across 8 files, included in the full unit count |
| `npm run lint` | PASS |
| `npm run typecheck` | PASS; also passed after the fresh build and restoration of baseline `next-env.d.ts` |
| `npm run test` | 1185 PASS across 66 files; 0 failed; 0 skipped |
| `npm run build` | PASS on fresh generated output |
| Authored-content validation | PASS in explicitly labeled `--source-only` mode; 0 blocking errors |
| Operations configuration validation | PASS with synthetic configuration |
| Populated native-database content validation | NOT EXECUTED |
| Unchanged canonical M05 | NOT EXECUTED; environment preflight blocked |
| Related auth/reset browser scenarios | NOT EXECUTED; environment preflight blocked |

The 57 related checks cover forgot/reset/login/register routes, abuse budgets, crypto, host-stream validation and host SSE security. The 12 MIME checks include actual product captures, base64, quoted-printable with soft wrapping, 7bit/8bit bodies, multipart alternatives, HTML entities, attachment exclusion and missing-link preservation. They are not canonical release identities.

Two preparation failures were preserved rather than hidden. An initial related-test invocation had 44 passing assertions and one suite-load error because the extracted source lacked generated Prisma Client. The baseline `npm run db:generate` command generated that client from the unchanged schema before the fresh complete unit execution. An initial build panicked inside Turbopack persistence while reading copied `.next` output. Its logs, panic and cache fingerprints were retained; a fresh build with that generated output quarantined succeeded. Neither incident established a product failure. These follow-up preparation runs are disclosed; no canonical scenario retry or automatic Playwright retry occurred.

## Release blocker and complete-gate status

The frozen tools refer to PostgreSQL 16 `initdb`/`postgres` and Chromium headless-shell executables from the prior workspace. Those paths are now missing; no installed system or cached replacement was found. A Chromium restoration request to its existing distribution URL timed out. Native PostgreSQL was not substituted with an emulator, and browser scenarios were not skipped or simulated. `RG03-Runtime-Blocker.json` records the preflight and restoration limit.

The required fresh release manifest was rediscovered: 223 canonical browser/API identities and 38 supplemental identities are unchanged. The 186 native identities remain in the manifest. No prior execution count was inherited.

| Final-gate class | Required | Current PASS | Current failed | NOT EXECUTED |
| --- | ---: | ---: | ---: | ---: |
| Canonical browser/API | 223 | 0 | 0 | 223 |
| Supplemental browser/API | 38 | 0 | 0 | 38 |
| Native PostgreSQL | 186 | 0 | 0 | 186 |

Unexecuted identities are not skips or successful results. All-ten-games release coverage, billing/refund, auth/security/privacy, M13 lifecycle/recovery, responsive/mobile and CSP compatibility are **unverified in this final gate**. Zero recorded browser failures or retries does not imply success when no browser case executed.

## Freeze and deliverables

The required unchanged canonical M05 PASS prerequisite was not met. Accordingly, **no RG03 frozen checkpoint and no Release-Candidate ZIP were created**. The latest safe frozen checkpoint remains the exact RG02 archive above. The corrected harness and its precise patch are preserved in the RG03 evidence bundle for continued verification; the RG02 checkpoint itself is unchanged.

Saved blocked deliverables:

- `Quddam-Phase-5.0J-2-RG03-Report.md`
- `Quddam-Phase-5.0J-2-RG03-Evidence.zip`
- Latest safe `Quddam-Phase-5.0J-2-RG02-frozen-checkpoint.zip`

To finish the already-authorized scope, restore the native PostgreSQL and Chromium execution prerequisites, run the unchanged M05 and related browser scenarios without retries, and freeze RG03 only after targeted PASS. Then restart the complete consolidated gate, including its required quality checks, from native identity 001 (`A/B concurrent paid`) and canonical browser identity 001 (`Arabic landing and account entry points render on desktop and mobile`), retaining the one-failure stop policy. Do not resume at case 149, inherit the component/unit PASS counts as full-gate execution, or issue a candidate until every required identity passes. This turn stops with the runtime blocker preserved.
